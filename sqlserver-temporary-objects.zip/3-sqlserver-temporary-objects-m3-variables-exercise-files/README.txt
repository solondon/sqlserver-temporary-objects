You can download the Credit database used in the course demos at: 
https://s3.amazonaws.com/pluralsight-free/sql-skills/creditbackup100.zip